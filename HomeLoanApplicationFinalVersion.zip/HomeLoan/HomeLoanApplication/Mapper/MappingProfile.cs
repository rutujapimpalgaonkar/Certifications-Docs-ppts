// File: MappingProfile.cs
using AutoMapper;
using HomeLoanApplication.Models;
using HomeLoanApplication.DTOs;

namespace HomeLoanApplication
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<IncomeDetail, IncomeDetailDTO>();  // Map IncomeDetail to IncomeDetailDTO
            CreateMap<IncomeDetailDTO, IncomeDetail>();  // Map IncomeDetailDTO to IncomeDetail
        }
    }
}
