using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeLoanApplication.Data;
using HomeLoanApplication.Models;
using HomeLoanApplication.DTOs;

namespace HomeLoanApplication.Controllers
{
    [Route("api/loans")]
    [ApiController]
    public class LoanApplicationController : ControllerBase
    {
        private readonly HomeLoanContext _context;

        public LoanApplicationController(HomeLoanContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<LoanApplication>>> GetLoanApplications()
        {
            return await _context.LoanApplications.Include(l => l.User).ToListAsync();
        }

        [HttpPost]
        public async Task<ActionResult<LoanApplication>> CreateLoanApplication([FromBody] LoanApplication loanApplication)
        {
            _context.LoanApplications.Add(loanApplication);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetLoanApplications), new { id = loanApplication.ApplicationId }, loanApplication);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<LoanApplication>> GetLoanApplication(int id)
        {
            var loanApplication = await _context.LoanApplications.Include(l => l.User).FirstOrDefaultAsync(l => l.ApplicationId == id);

            if (loanApplication == null)
            {
                return NotFound();
            }

            return loanApplication;
        }
    }
}
