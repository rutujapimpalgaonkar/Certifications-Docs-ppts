// File: Controllers/IncomeDetailController.cs
using HomeLoanApplication.Models;
using HomeLoanApplication.DTOs;
using HomeLoanApplication.Services;  // Import service
using Microsoft.AspNetCore.Mvc;

namespace HomeLoanApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IncomeDetailController : ControllerBase
    {
        private readonly IIncomeDetailService _incomeDetailService;

        // Inject IncomeDetailService into controller
        public IncomeDetailController(IIncomeDetailService incomeDetailService)
        {
            _incomeDetailService = incomeDetailService;
        }

        // GET: api/IncomeDetail/5
        [HttpGet("{id}")]
        public async Task<ActionResult<IncomeDetailDTO>> GetIncomeDetail(int id)
        {
            var incomeDetail = await _incomeDetailService.GetIncomeDetailById(id);
            if (incomeDetail == null)
            {
                return NotFound();
            }
            return Ok(incomeDetail);
        }

        // GET: api/IncomeDetail
        [HttpGet]
        public async Task<ActionResult<IEnumerable<IncomeDetailDTO>>> GetAllIncomeDetails()
        {
            var incomeDetails = await _incomeDetailService.GetAllIncomeDetails();
            return Ok(incomeDetails);
        }

        // POST: api/IncomeDetail
        [HttpPost]
        public async Task<ActionResult> CreateIncomeDetail(IncomeDetailDTO incomeDetailDto)
        {
            await _incomeDetailService.CreateIncomeDetail(incomeDetailDto);
          //  return CreatedAtAction(nameof(GetIncomeDetail), new { id = incomeDetailDto.UserId }, incomeDetailDto);
          return Ok();
        }

        // PUT: api/IncomeDetail/5
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateIncomeDetail(int id, IncomeDetailDTO incomeDetailDto)
        {
            await _incomeDetailService.UpdateIncomeDetail(id, incomeDetailDto);  // Corrected here
            return NoContent();
        }


        // DELETE: api/IncomeDetail/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteIncomeDetail(int id)
        {
            await _incomeDetailService.DeleteIncomeDetail(id);
            return NoContent();
        }
    }
}
