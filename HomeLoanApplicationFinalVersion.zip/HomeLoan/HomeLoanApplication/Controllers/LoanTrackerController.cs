using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeLoanApplication.Data;
using HomeLoanApplication.Models;
using HomeLoanApplication.DTOs;

namespace HomeLoanApplication.Controllers
{
    [Route("api/loantrackers")]
    [ApiController]
    public class LoanTrackerController : ControllerBase
    {
        private readonly HomeLoanContext _context;

        public LoanTrackerController(HomeLoanContext context)
        {
            _context = context;
        }

        // GET: api/loantrackers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LoanTracker>>> GetLoanTrackers()
        {
            return await _context.LoanTrackers.Include(lt => lt.LoanApplication).ToListAsync();
        }

        // GET: api/loantrackers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LoanTracker>> GetLoanTracker(int id)
        {
            var loanTracker = await _context.LoanTrackers.Include(lt => lt.LoanApplication)
                                                          .FirstOrDefaultAsync(lt => lt.Id == id);

            if (loanTracker == null)
            {
                return NotFound();
            }

            return loanTracker;
        }

        // POST: api/loantrackers
        [HttpPost]
        public async Task<ActionResult<LoanTracker>> CreateLoanTracker([FromBody] LoanTracker loanTracker)
        {
            _context.LoanTrackers.Add(loanTracker);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetLoanTracker), new { id = loanTracker.Id }, loanTracker);
        }

        // PUT: api/loantrackers/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateLoanTracker(int id, [FromBody] LoanTracker loanTracker)
        {
            if (id != loanTracker.Id)
            {
                return BadRequest();
            }

            _context.Entry(loanTracker).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/loantrackers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLoanTracker(int id)
        {
            var loanTracker = await _context.LoanTrackers.FindAsync(id);
            if (loanTracker == null)
            {
                return NotFound();
            }

            _context.LoanTrackers.Remove(loanTracker);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
