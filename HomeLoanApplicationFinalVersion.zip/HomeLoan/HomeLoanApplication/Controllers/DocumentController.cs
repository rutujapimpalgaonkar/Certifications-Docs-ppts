// using Microsoft.AspNetCore.Mvc;
// using Microsoft.EntityFrameworkCore;
// using HomeLoanApplication.Data;
// using HomeLoanApplication.Models;
// using HomeLoanApplication.DTOs;

// namespace HomeLoanApplication.Controllers
// {
//     [Route("api/documents")]
//     [ApiController]
//     public class DocumentController : ControllerBase
//     {
//         private readonly HomeLoanContext _context;

//         public DocumentController(HomeLoanContext context)
//         {
//             _context = context;
//         }

//         // GET: api/documents
//         [HttpGet]
//         public async Task<ActionResult<IEnumerable<Document>>> GetDocuments()
//         {
//             return await _context.Documents.Include(d => d.LoanApplication).ToListAsync();
//         }

//         // GET: api/documents/5
//         [HttpGet("{id}")]
//         public async Task<ActionResult<Document>> GetDocument(int id)
//         {
//             var document = await _context.Documents.Include(d => d.LoanApplication)
//                                                    .FirstOrDefaultAsync(d => d.Id == id);

//             if (document == null)
//             {
//                 return NotFound();
//             }

//             return document;
//         }

//         // POST: api/documents
//         [HttpPost]
//         public async Task<ActionResult<Document>> CreateDocument([FromBody] Document document)
//         {
//             _context.Documents.Add(document);
//             await _context.SaveChangesAsync();

//             return CreatedAtAction(nameof(GetDocument), new { id = document.Id }, document);
//         }

//         // PUT: api/documents/5
//         [HttpPut("{id}")]
//         public async Task<IActionResult> UpdateDocument(int id, [FromBody] Document document)
//         {
//             if (id != document.Id)
//             {
//                 return BadRequest();
//             }

//             _context.Entry(document).State = EntityState.Modified;
//             await _context.SaveChangesAsync();

//             return NoContent();
//         }

//         // DELETE: api/documents/5
//         [HttpDelete("{id}")]
//         public async Task<IActionResult> DeleteDocument(int id)
//         {
//             var document = await _context.Documents.FindAsync(id);
//             if (document == null)
//             {
//                 return NotFound();
//             }

//             _context.Documents.Remove(document);
//             await _context.SaveChangesAsync();

//             return NoContent();
//         }
//     }
// }
