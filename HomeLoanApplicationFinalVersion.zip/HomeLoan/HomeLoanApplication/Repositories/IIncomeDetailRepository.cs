using HomeLoanApplication.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HomeLoanApplication.Repositories
{
    public interface IIncomeDetailRepository
    {
        Task<IncomeDetail> GetIncomeDetailByIdAsync(int id);  // Get a specific IncomeDetail by ID
        Task<IEnumerable<IncomeDetail>> GetAllIncomeDetailsAsync();  // Get all IncomeDetails
        Task<IncomeDetail> AddIncomeDetailAsync(IncomeDetail incomeDetail);  // Add a new IncomeDetail
        Task<IncomeDetail> UpdateIncomeDetailAsync(int id, IncomeDetail incomeDetail);  // Update an existing IncomeDetail
        Task<bool> DeleteIncomeDetailAsync(int id);  // Delete an IncomeDetail by ID
    }
}
