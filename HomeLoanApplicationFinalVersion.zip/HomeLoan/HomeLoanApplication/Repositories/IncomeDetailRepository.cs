using HomeLoanApplication.Models;  
using HomeLoanApplication.Data;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace HomeLoanApplication.Repositories
{
    public class IncomeDetailRepository : IIncomeDetailRepository
    {
        private readonly HomeLoanContext _context;

        public IncomeDetailRepository(HomeLoanContext context)
        {
            _context = context;
        }

        // Get a specific IncomeDetail by its ID
        public async Task<IncomeDetail> GetIncomeDetailByIdAsync(int id)
        {
            return await _context.IncomeDetails.FindAsync(id);
        }

        // Get all IncomeDetails
        public async Task<IEnumerable<IncomeDetail>> GetAllIncomeDetailsAsync()
        {
            return await _context.IncomeDetails.ToListAsync();
        }

        // Create a new IncomeDetail
        public async Task<IncomeDetail> AddIncomeDetailAsync(IncomeDetail incomeDetail)
        {
            _context.IncomeDetails.Add(incomeDetail);
            await _context.SaveChangesAsync();
            return incomeDetail;
        }

        // Update an existing IncomeDetail
        public async Task<IncomeDetail> UpdateIncomeDetailAsync(int id, IncomeDetail incomeDetail)
        {
            var existingIncomeDetail = await _context.IncomeDetails.FindAsync(id);
            if (existingIncomeDetail == null)
            {
                return null; // or throw an exception if needed
            }

            existingIncomeDetail.NetSalary = incomeDetail.NetSalary;
            existingIncomeDetail.EmploymentType = incomeDetail.EmploymentType;
            existingIncomeDetail.EmployerName = incomeDetail.EmployerName;
          //  existingIncomeDetail.LoanApplicationId = incomeDetail.LoanApplicationId;

            await _context.SaveChangesAsync();
            return existingIncomeDetail;
        }

        // Delete an IncomeDetail by its ID
        public async Task<bool> DeleteIncomeDetailAsync(int id)
        {
            var incomeDetail = await _context.IncomeDetails.FindAsync(id);
            if (incomeDetail == null)
            {
                return false;
            }

            _context.IncomeDetails.Remove(incomeDetail);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
