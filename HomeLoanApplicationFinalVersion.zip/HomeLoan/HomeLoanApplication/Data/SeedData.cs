using HomeLoanApplication.Data;
using HomeLoanApplication.Models;
using System.Linq;

namespace HomeLoanApplication
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider, HomeLoanContext context)
        {
            // Ensure the database is created
            context.Database.EnsureCreated();

            // If there are no users, seed some initial data
            if (!context.Users.Any())
            {
                var admin = new User { Name = "Admin", Email = "admin@example.com", Role = "Admin", IsActive = true };
                var customer = new User { Name = "Customer", Email = "customer@example.com", Role = "Customer", IsActive = true };

                context.Users.AddRange(admin, customer);
                context.SaveChanges();
            }
        }
    }
}
