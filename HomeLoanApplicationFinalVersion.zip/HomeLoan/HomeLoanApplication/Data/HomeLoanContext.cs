using Microsoft.EntityFrameworkCore;
using HomeLoanApplication.Models;

namespace HomeLoanApplication.Data
{
    public class HomeLoanContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<LoanApplication> LoanApplications { get; set; }
        public DbSet<LoanTracker> LoanTrackers { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<IncomeDetail> IncomeDetails { get; set; }

        public HomeLoanContext(DbContextOptions<HomeLoanContext> options)
            : base(options)
        {
        }

protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    base.OnModelCreating(modelBuilder);

    // Configure one-to-many relationship between LoanApplication and IncomeDetail
    modelBuilder.Entity<IncomeDetail>()
        .HasKey(i => i.IncomeDetailId);         // Refers to the navigation property (LoanApplication)
         

    // Configure one-to-one relationship between Account and LoanApplication
    modelBuilder.Entity<Account>()
        .HasOne(a => a.LoanApplication)  // Account has one LoanApplication
        .WithOne(l => l.Account)  // LoanApplication has one Account
        .HasForeignKey<Account>(a => a.ApplicationId)  // Explicitly define the foreign key in Account
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascade delete (Restrict)

    // Configure one-to-one relationship between Document and LoanApplication
 modelBuilder.Entity<Document>()
    .HasKey(l => l.DocumentID);  // LoanApplication has many Documents
     // Set foreign key to null when LoanApplication is deleted
  // Set foreign key to null when LoanApplication is deleted
  // Set foreign key to null when LoanApplication is deleted

    // Configure one-to-one relationship between LoanTracker and LoanApplication
    modelBuilder.Entity<LoanTracker>()
        .HasOne(t => t.LoanApplication)
        .WithOne(l => l.LoanTracker)
        .HasForeignKey<LoanTracker>(t => t.ApplicationId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascade delete (Restrict)

    // Explicitly configure the primary key for LoanApplication
    modelBuilder.Entity<LoanApplication>()
        .HasKey(l => l.ApplicationId);  // This assumes ApplicationId is the primary key

    // Configure one-to-many relationship between LoanApplication and IncomeDetail (again)
    modelBuilder.Entity<LoanApplication>()
        .HasMany(l => l.IncomeDetails);
          // One LoanApplication has many IncomeDetails
        // Foreign Key in IncomeDetail (ApplicationId)
       // Prevent cascade delete (Restrict)
}

    }}