using HomeLoanApplication;
using HomeLoanApplication.Data;
using HomeLoanApplication.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using HomeLoanApplication.Repositories;  // For repository interfaces and classes
using HomeLoanApplication.Services;     // For service interfaces and classes
using AutoMapper;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// Register DbContext with SQL Server connection string
builder.Services.AddDbContext<HomeLoanContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Register Repositories
builder.Services.AddScoped<IIncomeDetailRepository, IncomeDetailRepository>();

// Register Services
builder.Services.AddScoped<IIncomeDetailService, IncomeDetailService>();

// Add AutoMapper for DTO mappings (if you're using AutoMapper)
builder.Services.AddAutoMapper(typeof(MappingProfile)); // Register AutoMapper using MappingProfile


// Add Swagger configuration
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "HomeLoanApplication API",
        Version = "v1"
    });
});

// Add controllers
builder.Services.AddControllers();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    // Enable Swagger UI in development
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "HomeLoanApplication API V1");
        c.RoutePrefix = string.Empty;  // Swagger UI at http://localhost:5000
    });
}

// Enable HTTPS redirection
app.UseHttpsRedirection();

// Enable routing
app.UseRouting();

// Map controllers
app.MapControllers();

app.Run();
