using HomeLoanApplication.Models;
using HomeLoanApplication.Data;
using System.Threading.Tasks;

namespace HomeLoanApplication.Services
{
    public class LoanApplicationService : ILoanApplicationService
    {
        private readonly HomeLoanContext _context;

        public LoanApplicationService(HomeLoanContext context)
        {
            _context = context;
        }

        public async Task<LoanApplication> CreateLoanApplicationAsync(LoanApplication loanApplication)
        {
            _context.LoanApplications.Add(loanApplication);
            await _context.SaveChangesAsync();
            return loanApplication;
        }

        public async Task<LoanApplication> GetLoanApplicationByIdAsync(int applicationId)
        {
            return await _context.LoanApplications.FindAsync(applicationId);
        }
    }
}
