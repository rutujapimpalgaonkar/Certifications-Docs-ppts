using HomeLoanApplication.Repositories;  // For IIncomeDetailRepository
using AutoMapper;                       // For AutoMapper
using HomeLoanApplication.Models;      // For domain models
using HomeLoanApplication.DTOs;        // For DTOs

namespace HomeLoanApplication.Services
{
    public class IncomeDetailService : IIncomeDetailService
    {
        private readonly IIncomeDetailRepository _incomeDetailRepository;
        private readonly IMapper _mapper;

        // Constructor injecting the repository and AutoMapper
        public IncomeDetailService(IIncomeDetailRepository incomeDetailRepository, IMapper mapper)
        {
            _incomeDetailRepository = incomeDetailRepository;
            _mapper = mapper;
        }

        // Get IncomeDetail by ID
        public async Task<IncomeDetailDTO> GetIncomeDetailById(int id)
        {
            var incomeDetail = await _incomeDetailRepository.GetIncomeDetailByIdAsync(id);
            return _mapper.Map<IncomeDetailDTO>(incomeDetail);  // Map to DTO
        }

        // Get all IncomeDetails
        public async Task<IEnumerable<IncomeDetailDTO>> GetAllIncomeDetails()
        {
            var incomeDetails = await _incomeDetailRepository.GetAllIncomeDetailsAsync();
            return _mapper.Map<IEnumerable<IncomeDetailDTO>>(incomeDetails);  // Map list to DTOs
        }

        // Create new IncomeDetail
        public async Task CreateIncomeDetail(IncomeDetailDTO incomeDetailDto)
        {
            var incomeDetail = _mapper.Map<IncomeDetail>(incomeDetailDto);  // Map DTO to domain model
        
            await _incomeDetailRepository.AddIncomeDetailAsync(incomeDetail);
        }

        // Update existing IncomeDetail
        public async Task UpdateIncomeDetail(int id, IncomeDetailDTO incomeDetailDto)
        {
            var incomeDetail = await _incomeDetailRepository.GetIncomeDetailByIdAsync(id);
            if (incomeDetail != null)
            {
                _mapper.Map(incomeDetailDto, incomeDetail);  // Map DTO to existing domain model
                await _incomeDetailRepository.UpdateIncomeDetailAsync(id, incomeDetail);
            }
        }

        // Delete IncomeDetail by ID
        public async Task DeleteIncomeDetail(int id)
        {
            await _incomeDetailRepository.DeleteIncomeDetailAsync(id);
        }

        public Task<bool> UpdateIncomeDetailAsync(int id, IncomeDetailDTO incomeDetailDTO)
        {
            throw new NotImplementedException();
        }
    }
}
