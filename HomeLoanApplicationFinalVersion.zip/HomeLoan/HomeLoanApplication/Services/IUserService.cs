using HomeLoanApplication.Models;


namespace HomeLoanApplication.Services
{
    public interface IUserService
    {
        Task<User> GetUserByIdAsync(int userId);
        Task<User> RegisterUserAsync(User user, string password);
    }
}
