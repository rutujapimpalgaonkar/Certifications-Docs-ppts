using HomeLoanApplication.Models;
using System.Threading.Tasks;

namespace HomeLoanApplication.Services
{
    public interface ILoanApplicationService
    {
        Task<LoanApplication> CreateLoanApplicationAsync(LoanApplication loanApplication);
        Task<LoanApplication> GetLoanApplicationByIdAsync(int applicationId);
    }
}
