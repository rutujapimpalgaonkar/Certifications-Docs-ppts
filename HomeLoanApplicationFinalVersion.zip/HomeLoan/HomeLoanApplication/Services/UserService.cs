using HomeLoanApplication.Models;
using HomeLoanApplication.Services; 
namespace HomeLoanApplication.Data{

public class UserService : IUserService
{
    private readonly HomeLoanContext _context;

    public UserService(HomeLoanContext context)
    {
        _context = context;
    }

    public async Task<User> GetUserByIdAsync(int userId)
    {
        return await _context.Users.FindAsync(userId);
    }

    public async Task<User> RegisterUserAsync(User user, string password)
    {
        // Implement user registration logic here (e.g., hash password, save to database)
        _context.Users.Add(user);
        await _context.SaveChangesAsync();
        return user;
    }
}
}