using HomeLoanApplication.Repositories;
using HomeLoanApplication.DTOs;


    namespace HomeLoanApplication.Services
    {
        public interface IIncomeDetailService
        {
            Task<IncomeDetailDTO> GetIncomeDetailById(int id);
            Task<IEnumerable<IncomeDetailDTO>> GetAllIncomeDetails();
            Task CreateIncomeDetail(IncomeDetailDTO incomeDetailDto);
            Task UpdateIncomeDetail(int id, IncomeDetailDTO incomeDetailDto);
            Task DeleteIncomeDetail(int id);
        Task<bool> UpdateIncomeDetailAsync(int id, IncomeDetailDTO incomeDetailDTO);
    }
    }
