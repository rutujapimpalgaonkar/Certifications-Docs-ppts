namespace HomeLoanApplication.Models{

public class Account
{
    public int Id { get; set; } 
    public int ApplicationId { get; set; }
    public decimal Balance { get; set; }  // Loan amount transferred after approval

    public LoanApplication LoanApplication { get; set; }  // Navigation property to LoanApplication
}
}