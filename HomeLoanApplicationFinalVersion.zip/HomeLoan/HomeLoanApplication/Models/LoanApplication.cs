using System.ComponentModel.DataAnnotations;

namespace HomeLoanApplication.Models
{
    public class LoanApplication
    {
        
        [Key]
        public int ApplicationId { get; set; }
        public int UserId { get; set; }
        public decimal LoanAmountRequested { get; set; }
        public decimal MonthlyIncome { get; set; }
        public int Tenure { get; set; }
        public string? PropertyLocation { get; set; }
        public string? PropertyName { get; set; }
        public decimal EstimatedPropertyCost { get; set; }
        public string? ApplicationStatus { get; set; }

        // Navigation properties

        
        // Collection navigation property to IncomeDetails
          public ICollection<Document> Documents { get; set; } 
        public ICollection<IncomeDetail>? IncomeDetails { get; set; }
         public User? User { get; set; }           // Navigation property to User
        public IncomeDetail? IncomeDetail { get; set; }  // Navigation property to IncomeDetail
        public Document? Document { get; set; }   // Navigation property to Document
        public LoanTracker? LoanTracker { get; set; }  // Navigation property to LoanTracker
        public Account? Account { get; set; }     // Navigation property to Account
    }
}
