using System.ComponentModel.DataAnnotations;

namespace HomeLoanApplication.Models
{
    public class IncomeDetail
    {
        [Key]
        public int IncomeDetailId { get; set; }  // Assuming this is the primary key
        public decimal NetSalary { get; set; }
        public string? EmploymentType { get; set; }
        public string? EmployerName { get; set; }
      //   public int ApplicationId { get; set; }  // Foreign Key reference to LoanApplication or another model

       
       //  public LoanApplication LoanApplication { get; set; }
        // Navigation property for the related LoanApplication
    }

}


