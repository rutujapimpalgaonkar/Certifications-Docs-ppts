namespace HomeLoanApplication.Models{

   public class Document
   {
      public int DocumentID { get; set; }
   //   public int? ApplicationId { get; set; }
      public string DocumentType { get; set; } // e.g., Aadhar, PAN
      public string DocumentUrl { get; set; } // URL or path of the document uploaded
   //   public LoanApplication LoanApplication { get; set; }
   }
}