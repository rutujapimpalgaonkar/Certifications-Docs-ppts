namespace HomeLoanApplication.Models{

public class LoanTracker
{
    public int Id { get; set; } 
    public int ApplicationId { get; set; }
    public string Status { get; set; }  // e.g., "Sent for Verification", "Approved", "Rejected"

    public LoanApplication LoanApplication { get; set; }  // Navigation property to LoanApplication
}
}