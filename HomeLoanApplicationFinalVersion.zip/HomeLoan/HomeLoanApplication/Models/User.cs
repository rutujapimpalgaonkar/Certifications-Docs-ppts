// User.cs
namespace HomeLoanApplication.Models{
public class User
{
    public int UserId { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }  // Placeholder, can be hashed later
    public string Role { get; set; }  // e.g., Admin, Customer
    public bool IsActive { get; set; }  // If the user is active or not

     public ICollection<LoanApplication> LoanApplications { get; set; }
}
}