﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HomeLoanApplication.Migrations
{
    /// <inheritdoc />
    public partial class SecoundCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_IncomeDetails_LoanApplications_ApplicationId",
                table: "IncomeDetails");

            migrationBuilder.DropIndex(
                name: "IX_IncomeDetails_ApplicationId",
                table: "IncomeDetails");

            migrationBuilder.DropColumn(
                name: "ApplicationId",
                table: "IncomeDetails");

            migrationBuilder.AddColumn<int>(
                name: "LoanApplicationApplicationId",
                table: "IncomeDetails",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_IncomeDetails_LoanApplicationApplicationId",
                table: "IncomeDetails",
                column: "LoanApplicationApplicationId");

            migrationBuilder.AddForeignKey(
                name: "FK_IncomeDetails_LoanApplications_LoanApplicationApplicationId",
                table: "IncomeDetails",
                column: "LoanApplicationApplicationId",
                principalTable: "LoanApplications",
                principalColumn: "ApplicationId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_IncomeDetails_LoanApplications_LoanApplicationApplicationId",
                table: "IncomeDetails");

            migrationBuilder.DropIndex(
                name: "IX_IncomeDetails_LoanApplicationApplicationId",
                table: "IncomeDetails");

            migrationBuilder.DropColumn(
                name: "LoanApplicationApplicationId",
                table: "IncomeDetails");

            migrationBuilder.AddColumn<int>(
                name: "ApplicationId",
                table: "IncomeDetails",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_IncomeDetails_ApplicationId",
                table: "IncomeDetails",
                column: "ApplicationId");

            migrationBuilder.AddForeignKey(
                name: "FK_IncomeDetails_LoanApplications_ApplicationId",
                table: "IncomeDetails",
                column: "ApplicationId",
                principalTable: "LoanApplications",
                principalColumn: "ApplicationId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
