// DTO for IncomeDetail
namespace HomeLoanApplication.DTOs
{
    public class IncomeDetailDTO
    {
       // public int UserId { get; set; }
        public decimal NetSalary { get; set; }
        public string EmploymentType { get; set; }
        public string EmployerName { get; set; }
        public decimal MonthlyIncome { get; set; }
        public object IncomeDetailId { get; internal set; }
    }
}