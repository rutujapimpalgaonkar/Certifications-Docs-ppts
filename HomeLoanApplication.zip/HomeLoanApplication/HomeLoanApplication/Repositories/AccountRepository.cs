using HomeLoanApplication.Data;
using HomeLoanApplication.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace HomeLoanApplication.Repositories
{
    public class AccountRepository : IAccountRepository
    {
        private readonly HomeLoanContext _context;

        public AccountRepository(HomeLoanContext context)
        {
            _context = context;
        }

        public async Task<bool> AccountExistsAsync(int accountId)
        {
            return await _context.Accounts.AnyAsync(a => a.AccountId == accountId);
        }

        public void Add(Account account)
        {
            throw new NotImplementedException();
        }

        public void Delete(Account account)
        {
            throw new NotImplementedException();
        }

        public Task<Account> GetByIdAsync(int accountId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> SaveAsync()
        {
            throw new NotImplementedException();
        }

        public void Update(Account account)
        {
            throw new NotImplementedException();
        }
    }
}
