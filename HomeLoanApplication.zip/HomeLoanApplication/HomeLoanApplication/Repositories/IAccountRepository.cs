using HomeLoanApplication.Models;
using System.Threading.Tasks;

namespace HomeLoanApplication.Repositories
{
    public interface IAccountRepository
    {
        Task<bool> AccountExistsAsync(int accountId);
        void Delete(Account account);
        Task<Account> GetByIdAsync(int id);
        Task<bool> SaveAsync();
        void Update(Account account);
    }
}
