using HomeLoanApplication.Models;

namespace HomeLoanApplication.Services
{
    public interface IAccountService
    {
        Task<bool> CreateAccountAsync(Account account);
        Task<bool> DeleteAccountAsync(int accountId);
        Task GetAccountByIdAsync(int id);
        Task GetAllAccountsAsync();
        Task<bool> UpdateAccountAsync(Account updatedAccount);
        Task<bool> ValidateAccountExistsAsync(int accountId); // Validate AccountId
    }
}
