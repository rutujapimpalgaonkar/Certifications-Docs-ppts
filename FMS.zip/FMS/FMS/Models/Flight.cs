﻿using System;
using System.Collections.Generic;

namespace FMS.Models;

public partial class Flight
{
    public int Id { get; set; }

    public string FlightNumber { get; set; } = null!;

    public string Departure { get; set; } = null!;

    public string Arrival { get; set; } = null!;

    public decimal Price { get; set; }
}
