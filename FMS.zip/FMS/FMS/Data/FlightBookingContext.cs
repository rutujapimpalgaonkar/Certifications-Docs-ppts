using Microsoft.EntityFrameworkCore;
using FMS.Models; // Adjust this to your actual namespace

public class FlightBookingContext : DbContext
{
    public FlightBookingContext(DbContextOptions<FlightBookingContext> options) : base(options) { }

    public DbSet<User> Users { get; set; }
    public DbSet<Flight> Flights { get; set; }
}
