using Microsoft.AspNetCore.Mvc;
using FMS; // Replace with your actual namespace
using FMS.Models; // Replace with your actual namespace
using System.Linq;

public class AdminsController : Controller
{
    private readonly FlightBookingContext _context;

    public AdminsController(FlightBookingContext context)
    {
        _context = context;
    }

    public IActionResult Login()
    {
                return View();
    }
    // GET: Admin
    // public IActionResult Index()
    // {
    //     var flights = _context.Flights.ToList();
    //     return View(flights);
    // }

    // // GET: Admin/Create
    // public IActionResult Create() => View();

    // // POST: Admin/Create
    // [HttpPost]
    // public IActionResult Create(Flight flight)
    // {
    //     if (ModelState.IsValid)
    //     {
    //         _context.Flights.Add(flight);
    //         _context.SaveChanges();
    //         return RedirectToAction("Index");
    //     }
    //     return View(flight);
    // }

    // // GET: Admin/Edit/5
    // public IActionResult Edit(int id)
    // {
    //     var flight = _context.Flights.Find(id);
    //     if (flight == null) return NotFound();
    //     return View(flight);
    // }

    // // POST: Admin/Edit/5
    // [HttpPost]
    // public IActionResult Edit(Flight flight)
    // {
    //     if (ModelState.IsValid)
    //     {
    //         _context.Flights.Update(flight);
    //         _context.SaveChanges();
    //         return RedirectToAction("Index");
    //     }
    //     return View(flight);
    // }

    // // GET: Admin/Delete/5
    // public IActionResult Delete(int id)
    // {
    //     var flight = _context.Flights.Find(id);
    //     if (flight == null) return NotFound();
    //     return View(flight);
    // }

    // // POST: Admin/Delete/5
    // [HttpPost, ActionName("Delete")]
    // public IActionResult DeleteConfirmed(int id)
    // {
    //     var flight = _context.Flights.Find(id);
    //     _context.Flights.Remove(flight);
    //     _context.SaveChanges();
    //     return RedirectToAction("Index");
    // }
}
